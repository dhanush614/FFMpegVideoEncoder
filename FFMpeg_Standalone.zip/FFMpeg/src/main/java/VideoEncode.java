import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Iterator;

import javax.security.auth.Subject;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.collection.IndependentObjectSet;
import com.filenet.api.constants.ClassNames;
import com.filenet.api.core.Connection;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.Folder;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.property.Properties;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.UserContext;
/*
import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;
import net.bramp.ffmpeg.probe.FFmpegFormat;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;*/
import ws.schild.jave.Encoder;
import ws.schild.jave.MultimediaObject;
import ws.schild.jave.encode.AudioAttributes;
import ws.schild.jave.encode.EncodingAttributes;
import ws.schild.jave.encode.VideoAttributes;
import ws.schild.jave.info.AudioInfo;
import ws.schild.jave.info.MultimediaInfo;
import ws.schild.jave.info.VideoInfo;
import ws.schild.jave.info.VideoSize;
import ws.schild.jave.process.ProcessLocator;
import ws.schild.jave.process.ffmpeg.DefaultFFMPEGLocator;
//import net.bramp.ffmpeg.probe.FFmpegStream;

public class VideoEncode {
	 private static Connection conn = null;
	 public static Connection getCEConn()
	 {

	  try {

	   String ceURI = "http://localhost:9080/wsi/FNCEWS40MTOM/";
	   String userName ="dadmin";
	   String password ="dadmin";
	   if(conn==null){
	   conn = Factory.Connection.getConnection(ceURI);
	   Subject subject = UserContext.createSubject(conn, userName, password, null);
	   UserContext uc = UserContext.get();
	   uc.pushSubject(subject);
	   }

	  } catch (Exception e1) {
	   // TODO Auto-generated catch block
	   e1.printStackTrace();
	  }
	  System.out.println("CE Conn :: "+conn);
	  return conn;
	 }
	 public static void downloadDoc(String osName) throws IOException{
	  
	  try{
	   //get the CE document
	   
	   Connection conn = getCEConn();
	   Domain domain = Factory.Domain.fetchInstance(conn,null, null);
	   ObjectStore objStore = Factory.ObjectStore.fetchInstance(domain, osName,null);
	   SearchScope searchScope = new SearchScope(objStore);

	   int count=1;
	   String sqlStr = "SELECT * FROM [Document] WHERE [Id] = '{F0F2BB7F-0000-C717-851F-EB0755ECD1B0}'";
	   SearchSQL searchSQL = new SearchSQL(sqlStr);
	   System.out.println("Query ::"+sqlStr);
	   IndependentObjectSet independentObjectSet = searchScope.fetchObjects(searchSQL, new Integer(10), null, new Boolean(true)); 
	   String docTitle=null;
	   if(!(independentObjectSet.isEmpty())){
	    Iterator it=independentObjectSet.iterator();
	    while(it.hasNext()) {
	     Document doc=(Document)it.next();
	     Properties documentProperties = doc.getProperties();
	     docTitle=documentProperties.getStringValue("DocumentTitle");
	     System.out.println("Doc Title :: "+ docTitle);
	     ContentElementList docContentList = doc.get_ContentElements();
	     Iterator iter = docContentList.iterator();
	     count++; 
	     while (iter.hasNext() )
	     {
	         ContentTransfer ct = (ContentTransfer) iter.next();
	         InputStream stream = ct.accessContentStream();
	         File documentFile = new File("C://Users//Administrator//Encode//" + docTitle);
	         Path path = Paths.get(documentFile.toURI());
	         Files.copy(stream, path, StandardCopyOption.REPLACE_EXISTING);
	         try {
	        	 	File sourceVideo = new File("C://Users//Administrator//Encode//" + docTitle);
					String targetDocName = docTitle.split("\\.")[0] + ".mp4";
					File targetVideo = new File("C://Users//Administrator//Encode//" + targetDocName);
					MultimediaObject sourceVideoMultiMediaObject = new MultimediaObject(sourceVideo);

					MultimediaInfo multimediaInfo = sourceVideoMultiMediaObject.getInfo();
					String sourceFormat = multimediaInfo.getFormat();
					System.out.println("Source Format: " + sourceFormat);
					AudioInfo audioInfo = multimediaInfo.getAudio();
					int audioBitRate = audioInfo.getBitRate();
					int audioChannels = audioInfo.getChannels();
					int audioSamplingRate = audioInfo.getSamplingRate();

					// Audio Attributes
					AudioAttributes audio = new AudioAttributes();
					audio.setCodec("aac");
					audio.setBitRate(new Integer(audioBitRate));
					audio.setChannels(new Integer(audioChannels));
					audio.setSamplingRate(new Integer(audioSamplingRate));

					VideoInfo videoInfo = multimediaInfo.getVideo();
					int videoBitRate = videoInfo.getBitRate();
					VideoSize videoSize = videoInfo.getSize();
					int videoFrameRate = (int) videoInfo.getFrameRate();

					// Video Attributes
					VideoAttributes video = new VideoAttributes();
					video.setCodec("libx264");
					video.setBitRate(new Integer(videoBitRate));
					video.setSize(videoSize);
					video.setFrameRate(new Integer(videoFrameRate));

					// Encoding attributes
					EncodingAttributes encodingAttributes = new EncodingAttributes();
					encodingAttributes.setMapMetaData(true);
					encodingAttributes.setInputFormat(sourceFormat);
					encodingAttributes.setOutputFormat("mp4");
					encodingAttributes.setAudioAttributes(audio);
					encodingAttributes.setVideoAttributes(video);
	 			DefaultFFMPEGLocator locator= new  DefaultFFMPEGLocator();
	 	        String exePath= locator.getExecutablePath();
	 	        System.out.println("ffmpeg executable found in <"+exePath+">");
	 			// Encode
	 			Encoder encoder = new Encoder();
	 			encoder.encode(sourceVideoMultiMediaObject, targetVideo, encodingAttributes);

	 		} catch (Exception ex) {
	 			ex.printStackTrace();
	 		}
	 	

	         // Print element sequence number and content type of the element.
	         
	         System.out.println("done!");
	         stream.close();
	         } 
	     
	    }
	    System.out.println("Count:::;"+count);
	    System.out.println("Done");
	    }
	  }
	  catch(Exception e){
	   e.printStackTrace();
	  }
	 }


	public static void main(String[] args) throws IOException {
		downloadDoc("tos");
		/*try {
			File source = new File("C://Users//Administrator//Encode//InputFile.avi");

			File target = new File("C://Users//Administrator//Encode//OutputFile.mp4");


			// Audio Attributes
			AudioAttributes audio = new AudioAttributes();
			 audio.setCodec("aac");
			    audio.setBitRate(new Integer(128000));
			    audio.setSamplingRate(new Integer(48000));
			    audio.setChannels(new Integer(2));
			    audio.setBitRate(new Integer(192000));

			VideoAttributes video = new VideoAttributes();
			 video.setCodec("libx264");
			    video.setBitRate(new Integer(328000));
			    video.setFrameRate(new Integer(25));
			    VideoSize size = new VideoSize(1280, 720);
				video.setSize(size);

			// Encoding attributes
			EncodingAttributes attrs = new EncodingAttributes();
			attrs.setInputFormat("avi");
			attrs.setOutputFormat("mp4");
			attrs.setAudioAttributes(audio);
			attrs.setVideoAttributes(video);
			DefaultFFMPEGLocator locator= new  DefaultFFMPEGLocator();
	        String exePath= locator.getExecutablePath();
	        System.out.println("ffmpeg executable found in <"+exePath+">");
			// Encode
			Encoder encoder = new Encoder();
			encoder.encode(new MultimediaObject(source), target, attrs);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	
*/		/*FFmpeg ffmpeg = new FFmpeg("C://temp//1//jave//ffmpeg.exe");
		FFprobe ffprobe = new FFprobe("C://temp//1//jave//ffprobe.exe");
		FFmpegProbeResult probeResult = ffprobe.probe("C://Users//Administrator//Encode//InputFile.avi");
		FFmpegFormat format = probeResult.getFormat();
		System.out.format("%nFile: '%s' ; Format: '%s' ; Duration: %.3fs", 
			format.filename, 
			format.format_long_name,
			format.duration
		);

		FFmpegStream stream = probeResult.getStreams().get(0);
		System.out.format("%nCodec: '%s' ; Width: %dpx ; Height: %dpx",
			stream.codec_long_name,
			stream.width,
			stream.height
		);
		FFmpegBuilder builder = new FFmpegBuilder()
		  .setInput("C://Users//Administrator//Encode//InputFile.avi")     // Filename, or a FFmpegProbeResult
		  .overrideOutputFiles(true) // Override the output if it exists

		  .addOutput("C://Users//Administrator//Encode//OutputFile.mp4")   // Filename for the destination
		    .setFormat("mp4")        // Format is inferred from filename, or can be set  

		    .setAudioChannels(2)         // Mono audio
		    .setAudioCodec("aac")        // using the aac codec
		    .setAudioSampleRate(48_000)  // at 48KHz
		    .setAudioBitRate(32768)      // at 32 kbit/s

		    .setVideoCodec("libx264")     // Video using x264
		    .setVideoFrameRate(24, 1)     // at 24 frames per second
		    .setVideoResolution(640, 480) // at 640x480 resolution
		    .setVideoBitRate(160000)
		    .setStrict(FFmpegBuilder.Strict.EXPERIMENTAL) // Allow FFmpeg to use experimental specs
		    .done();

		FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);

		// Run a one-pass encode
		executor.createJob(builder).run();

		// Or run a two-pass encode (which is better quality at the cost of being slower)
		executor.createTwoPassJob(builder).run();
*/	}

}
