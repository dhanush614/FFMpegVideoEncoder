import java.io.File;
import java.io.IOException;

/*import net.bramp.ffmpeg.FFmpeg;
import net.bramp.ffmpeg.FFmpegExecutor;
import net.bramp.ffmpeg.FFprobe;
import net.bramp.ffmpeg.builder.FFmpegBuilder;
import net.bramp.ffmpeg.probe.FFmpegFormat;
import net.bramp.ffmpeg.probe.FFmpegStream;
import net.bramp.ffmpeg.probe.FFmpegProbeResult;*/
import ws.schild.jave.Encoder;
import ws.schild.jave.MultimediaObject;
import ws.schild.jave.encode.AudioAttributes;
import ws.schild.jave.encode.EncodingAttributes;
import ws.schild.jave.encode.VideoAttributes;
import ws.schild.jave.info.AudioInfo;
import ws.schild.jave.info.MultimediaInfo;
import ws.schild.jave.info.VideoInfo;
import ws.schild.jave.info.VideoSize;
import ws.schild.jave.progress.EchoingEncoderProgressListener;


public class VideoEncode {
	private void convertVideoFormat() {

		try {
			File source = new File("C://Encode//InputFile.wmv");

			File target = new File("C://Encode//OutputFile.mp4");
			MultimediaObject sourceVideoMultiMediaObject = new MultimediaObject(source);
			MultimediaInfo multimediaInfo = sourceVideoMultiMediaObject.getInfo();
			String sourceFormat = multimediaInfo.getFormat();

			AudioInfo audioInfo = multimediaInfo.getAudio();
			int audioBitRate = audioInfo.getBitRate();
			int audioChannels = audioInfo.getChannels();
			int audioSamplingRate = audioInfo.getSamplingRate();

			// Audio Attributes
			AudioAttributes audio = new AudioAttributes();
			audio.setCodec("aac");
			audio.setBitRate(new Integer(audioBitRate));
			audio.setChannels(new Integer(audioChannels));
			audio.setSamplingRate(new Integer(audioSamplingRate));

			VideoInfo videoInfo = multimediaInfo.getVideo();
			int videoBitRate = videoInfo.getBitRate();
			VideoSize videoSize = videoInfo.getSize();
			int videoFrameRate = (int) videoInfo.getFrameRate();

			// Video Attributes
			VideoAttributes video = new VideoAttributes();
			video.setCodec("libx264");
			video.setBitRate(new Integer(videoBitRate));
			video.setSize(videoSize);
			video.setFrameRate(new Integer(videoFrameRate));

			// Encoding attributes
			EncodingAttributes encodingAttributes = new EncodingAttributes();
			encodingAttributes.setMapMetaData(true);
			encodingAttributes.setInputFormat(sourceFormat);
			encodingAttributes.setOutputFormat("mp4");
			encodingAttributes.setAudioAttributes(audio);
			encodingAttributes.setVideoAttributes(video);

			// Encode
			System.out.println("Encode");
			Encoder encoder = new Encoder();
			encoder.encode(sourceVideoMultiMediaObject, target, encodingAttributes);
			
			/*
			 * String audioEn[] = encoder.getAudioEncoders(); Arrays.sort(audioEn);
			 * for(String a: audioEn) { System.out.println(a); } System.out.println();
			 * String vidioEn[] = encoder.getVideoEncoders(); Arrays.sort(vidioEn);
			 * for(String a: vidioEn) { System.out.println(a); } encoder.encode(new
			 * MultimediaObject(source), target, attrs);
			 */
		} catch (Exception ex) {
			ex.printStackTrace();
		}

		/*
		 * FFmpeg ffmpeg = new FFmpeg("C://Encode//ffmpeg.exe"); FFprobe ffprobe = new
		 * FFprobe("C://Encode//ffprobe.exe"); FFmpegProbeResult probeResult =
		 * ffprobe.probe("C://Encode//InputFile.3gpp"); FFmpegFormat format =
		 * probeResult.getFormat();
		 * System.out.format("%nFile: '%s' ; Format: '%s' ; Duration: %.3fs",
		 * format.filename, format.format_long_name, format.duration );
		 * 
		 * FFmpegStream stream = probeResult.getStreams().get(0);
		 * System.out.format("%nCodec: '%s' ; Width: %dpx ; Height: %dpx",
		 * stream.codec_long_name, stream.width, stream.height ); FFmpegBuilder builder
		 * = new FFmpegBuilder()
		 * 
		 * .setInput("C://Encode//InputFile.3gpp") // Filename, or a FFmpegProbeResult
		 * .overrideOutputFiles(true) // Override the output if it exists
		 * 
		 * .addOutput("C://Encode//OutputFile.mp4") // Filename for the destination
		 * .setFormat("mp4") // Format is inferred from filename, or can be set
		 * 
		 * .setAudioChannels(2) // Mono audio .setAudioCodec("aac") // using the aac
		 * codec .setAudioSampleRate(48_000) // at 48KHz .setAudioBitRate(128000) // at
		 * 128 kbit/s
		 * 
		 * .setVideoCodec("libx264") // Video using x264 .setVideoFrameRate(24, 1) // at
		 * 24 frames per second .setVideoResolution(1280, 720) // at 1280x720 resolution
		 * .setVideoBitRate(328000) .setStrict(FFmpegBuilder.Strict.EXPERIMENTAL) //
		 * Allow FFmpeg to use experimental specs .done();
		 * 
		 * FFmpegExecutor executor = new FFmpegExecutor(ffmpeg, ffprobe);
		 * 
		 * // Run a one-pass encode executor.createJob(builder).run();
		 * 
		 * // Or run a two-pass encode (which is better quality at the cost of being
		 * slower) executor.createTwoPassJob(builder).run();
		 */

	}

	public static void main(String[] args) throws IOException {
		VideoEncode ve = new VideoEncode();
		 ve.convertVideoFormat();
		/*String exeLocation = "C:\\Encode\\ffmpeg";
		String extractFullPath = "C:\\Encode\\InputFile.wmv";
		String dest = "C:\\Encode\\OutputFile.mp4";

		String cmd = exeLocation + " -i " + extractFullPath + " -c:v libx264 -crf 23 " + dest ;
		Runtime.getRuntime().exec(cmd);*/
	}

}
