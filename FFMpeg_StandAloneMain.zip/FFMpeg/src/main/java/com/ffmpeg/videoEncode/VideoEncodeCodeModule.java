package com.ffmpeg.videoEncode;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Iterator;

import com.filenet.api.collection.ContentElementList;
import com.filenet.api.constants.PropertyNames;
import com.filenet.api.core.ContentTransfer;
import com.filenet.api.core.Document;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.engine.EventActionHandler;
import com.filenet.api.events.ObjectChangeEvent;
import com.filenet.api.exception.EngineRuntimeException;
import com.filenet.api.property.FilterElement;
import com.filenet.api.property.PropertyFilter;
import com.filenet.api.util.Id;
import com.ibm.casemgmt.api.context.CaseMgmtContext;
import com.ibm.casemgmt.api.context.P8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleP8ConnectionCache;
import com.ibm.casemgmt.api.context.SimpleVWSessionCache;

import ws.schild.jave.Encoder;
import ws.schild.jave.MultimediaObject;
import ws.schild.jave.encode.AudioAttributes;
import ws.schild.jave.encode.EncodingAttributes;
import ws.schild.jave.encode.VideoAttributes;
import ws.schild.jave.info.AudioInfo;
import ws.schild.jave.info.MultimediaInfo;
import ws.schild.jave.info.VideoInfo;
import ws.schild.jave.info.VideoSize;

public class VideoEncodeCodeModule implements EventActionHandler {

	public void onEvent(ObjectChangeEvent event, Id subId) throws EngineRuntimeException {
		// TODO Auto-generated method stub
		System.out.println("--%% Inside OnEvent Method --%%");
		CaseMgmtContext origCmctx = null;
		try {
			P8ConnectionCache connCache = new SimpleP8ConnectionCache();
			origCmctx = CaseMgmtContext.set(new CaseMgmtContext(new SimpleVWSessionCache(), connCache));
			ObjectStore targetOS = event.getObjectStore();
			Id documentID = event.get_SourceObjectId();
			String documentTitle = fetchDocumentsAndSaveAsFiles(targetOS, documentID);
			System.out.println("--%% Document Title: " + documentTitle);
			File sourceVideo = new File(new URI("C://Users//Administrator//Encode//" + documentTitle));
			String targetDocName = documentTitle.split(".")[0];
			File targetVideo = new File(new URI("C://Users//Administrator//Encode//" + targetDocName + ".mp4"));
			MultimediaObject sourceVideoMultiMediaObject = new MultimediaObject(sourceVideo);
			MultimediaInfo multimediaInfo = sourceVideoMultiMediaObject.getInfo();
			String sourceFormat = multimediaInfo.getFormat();

			AudioInfo audioInfo = multimediaInfo.getAudio();
			int audioBitRate = audioInfo.getBitRate();
			int audioChannels = audioInfo.getChannels();
			int audioSamplingRate = audioInfo.getSamplingRate();

			// Audio Attributes
			AudioAttributes audio = new AudioAttributes();
			audio.setCodec("aac");
			audio.setBitRate(new Integer(audioBitRate));
			audio.setChannels(new Integer(audioChannels));
			audio.setSamplingRate(new Integer(audioSamplingRate));

			VideoInfo videoInfo = multimediaInfo.getVideo();
			int videoBitRate = videoInfo.getBitRate();
			VideoSize videoSize = videoInfo.getSize();
			int videoFrameRate = (int) videoInfo.getFrameRate();

			// Video Attributes
			VideoAttributes video = new VideoAttributes();
			video.setCodec("libx264");
			video.setBitRate(new Integer(videoBitRate));
			video.setSize(videoSize);
			video.setFrameRate(new Integer(videoFrameRate));

			// Encoding attributes
			EncodingAttributes encodingAttributes = new EncodingAttributes();
			encodingAttributes.setMapMetaData(true);
			encodingAttributes.setInputFormat(sourceFormat);
			encodingAttributes.setOutputFormat("mp4");
			encodingAttributes.setAudioAttributes(audio);
			encodingAttributes.setVideoAttributes(video);

			// Encode
			Encoder encoder = new Encoder();
			encoder.encode(sourceVideoMultiMediaObject, targetVideo, encodingAttributes);

		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			throw new RuntimeException(e);
		} finally {
			CaseMgmtContext.set(origCmctx);
		}
	}

	private String fetchDocumentsAndSaveAsFiles(ObjectStore targetOS, Id documentID) throws Exception {
		String docTitle = "";
		try {
			FilterElement fe = new FilterElement(null, null, null, "Owner Name", null);
			PropertyFilter pf = new PropertyFilter();
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.CONTENT_SIZE, null));
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.CONTENT_ELEMENTS, null));
			pf.addIncludeProperty(new FilterElement(null, null, null, PropertyNames.FOLDERS_FILED_IN, null));
			pf.addIncludeProperty(fe);
			Document doc = Factory.Document.fetchInstance(targetOS, documentID, pf);
			docTitle = doc.get_Name();
			System.out.println("--%%-- Document Title: " + docTitle);
			ContentElementList docContentList = doc.get_ContentElements();
			Iterator iter = docContentList.iterator();
			while (iter.hasNext()) {
				ContentTransfer ct = (ContentTransfer) iter.next();
				InputStream stream = ct.accessContentStream();
				Path path = Paths.get(new URI("C://Users//Administrator//Encode//" + docTitle));
				Files.copy(stream, path, StandardCopyOption.REPLACE_EXISTING);
			}
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
			throw new Exception(e);
		}
		return docTitle;

	}

}
